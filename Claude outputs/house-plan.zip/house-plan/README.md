# Georgy Residence — Electrical Plan

An interactive, static web page showing the house plan with toggleable electrical
layers, and a click-through view of each switchboard's switch layout.

No build step, no dependencies, no framework. Plain HTML, CSS and JavaScript.

---

## Deploying to GitHub Pages

1. Create a repository (for example `georgy-residence-plan`) and push these files to
   the `main` branch, with `index.html` at the repository root.

   ```bash
   git init
   git add .
   git commit -m "House electrical plan"
   git branch -M main
   git remote add origin git@github.com:<your-username>/georgy-residence-plan.git
   git push -u origin main
   ```

2. On GitHub: **Settings → Pages → Build and deployment**
   - Source: *Deploy from a branch*
   - Branch: `main`, folder: `/ (root)`

3. Wait a minute or two. The site appears at
   `https://<your-username>.github.io/georgy-residence-plan/`

The `.nojekyll` file is already included so GitHub serves the folder as-is.

> **Note on privacy.** On a free GitHub account, Pages only serves from a *public*
> repository, so the plan and its URL are publicly reachable. If you would rather
> keep it private, deploy the same folder to Cloudflare Pages from a private repo
> and put Cloudflare Access in front of it — no changes to these files are needed.

### Previewing locally

Just open `index.html` in a browser — everything is bundled as plain `<script>`
files, so it works straight from disk. To serve it over HTTP instead:

```bash
python3 -m http.server 8000
```

---

## How it works

```
index.html
assets/
  css/app.css            all styling, light + dark themes
  js/app.js              pan/zoom, layer toggles, panel, search
  data/plan-svg.js       the floor plan as one inline SVG string
  data/boards.js         every switchboard: position, room, module layout
```

### The plan

`plan-svg.js` holds the floor plan vectorised from
*Electrical drawing - Rev 5.pdf* (Sourorja Electricals, 16 Jan 2026).
Every shape carries a class naming the layer it belongs to:

| Class | Layer | What it is |
|---|---|---|
| `l-arch` | Architecture | walls, doors, furniture, room names |
| `l-fixtures` | Lights, fans & sockets | the equipment symbols |
| `l-switches` | Switches & boards | switch symbols and the `S…` board labels |
| `l-wiring` | Control wiring | which switch drives which fixture |
| `l-notes` | Extra notes | the under-cabinet light annotations |

Toggling a layer just adds `off-<layer>` to `<body>`; the CSS does the rest.

Coordinates are in the drawing's own space, viewBox `16 16 928 804`.

### The data

`assets/data/boards.js` defines one object per switchboard:

```js
{
  "id": "S16",
  "room": "Master Bedroom",
  "x": 407.9, "y": 735,          // position on the plan — don't change these
  "title": "Bedside switch",
  "note": "Closer to the room door",
  "faces": { "left": "Bed", "right": "Door" },
  "modules": [
    { "label": "Bedside lamp on top", "type": "light", "w": 1 },
    { "label": "Plug Point",          "type": "socket", "w": 2 },
    { "label": "Master Switch",       "type": "light", "w": 1, "optional": true }
  ]
}
```

- `type` is one of `light`, `fan`, `socket`, `socket-switch`, `heavy` — it picks the
  colour, matching the convention in the Figma board.
- `w` is the module width: `1` for a single switch, `2` for a socket or a regulator.
- `optional: true` draws it dashed and marks it *opt*.
- `faces` labels what sits either side of the board, drawn as the little arrows.

### Adding the boards that aren't documented yet

54 boards are marked on the plan. Seven currently have a layout — the ones carried
over from the Figma board. The rest show *"Layout not added yet"*.

To add one, find it by its `id` in `boards.js` and give it `title`, `note`, `faces`
and a `modules` array. Save, reload. That's the whole workflow.

### Mapping the Figma layouts

The seven layouts from Figma were matched to the Master Bedroom cluster
(`S11`–`S16`) by position. Those are **best guesses** and each is flagged as such in
the UI. If one is wrong, move the `title` / `note` / `faces` / `modules` block to the
correct board id and delete the `"confirmed": false` line once you're happy.

| Board | Figma layout | Guessed from |
|---|---|---|
| S11 | Main Switch Board | top wall, nearest the bedroom door |
| S12 | Above Table | top wall, beside the table |
| S15 | Bedside switch (away from door) | bottom wall, left of the bed |
| S16 | Bedside switch (near door) | bottom wall, right of the bed |
| S13 | Outside of Bathroom | just outside the master bathroom |
| S14 | Inside of Bathroom | inside the bathroom / dress corner |
| S14A | Dressing Table | dress area |

### Room assignment

Each board's `room` was derived from where it falls on the plan. A handful near a
wall between two spaces could reasonably belong to either — `S9`, `S9A`, `S10`
(Bathroom 2 vs Dress) and `S18` (Patio vs Kitchen) are the ones worth a second look.
Change the `room` string to regroup them in the sidebar.

---

## Keyboard & gestures

| | |
|---|---|
| Scroll / pinch | zoom |
| Drag | pan |
| `/` | focus search |
| `Esc` | close the panel |
| `index.html#S13` | deep-link straight to a board |

---

Drawing: Sourorja Electricals, B-Class Electrical Contractors, Thiruvalla.
Rev 5, 16 January 2026. Switch layouts from the *Georgy's House | Switch Boards*
Figma board.
