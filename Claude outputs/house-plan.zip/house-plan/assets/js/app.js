/* Georgy Residence — electrical plan viewer */
(function () {
  'use strict';

  var D = window.HOUSE_DATA;
  var SVG_NS = 'http://www.w3.org/2000/svg';
  var host = document.getElementById('plan-host');
  var $ = function (id) { return document.getElementById(id); };

  /* ---------------- plan ---------------- */

  host.innerHTML = window.PLAN_SVG;
  var svg = host.querySelector('svg');
  svg.setAttribute('id', 'plan-svg');

  var base = D.meta.viewBox.split(/\s+/).map(Number);
  var view = { x: base[0], y: base[1], w: base[2], h: base[3] };
  var lastK = null;

  function applyView() {
    svg.setAttribute('viewBox', view.x + ' ' + view.y + ' ' + view.w + ' ' + view.h);
    // keep markers a constant size on screen regardless of zoom
    var k = view.w / base[2];
    if (markers && k !== lastK) {
      lastK = k;
      markers.style.fontSize = (6 * k) + 'px';
      markers.style.setProperty('--mk-k', k);
      for (var i = 0; i < markerScaled.length; i++) {
        var s = markerScaled[i];
        if (s.set) s.set(k);
        else s.el.setAttribute(s.attr, (s.v * k).toFixed(2));
      }
    }
  }

  // Keep the plan's aspect independent of the stage so nothing is cropped.
  function fit() {
    view = { x: base[0], y: base[1], w: base[2], h: base[3] };
    applyView();
  }
  applyView();

  /* ---------------- markers ---------------- */

  var markers = null;
  var markerScaled = [];
  var byId = {};
  var markerEls = {};

  markers = document.createElementNS(SVG_NS, 'g');
  markers.setAttribute('id', 'markers');
  svg.appendChild(markers);

  D.boards.forEach(function (b) {
    byId[b.id] = b;
    var done = !!(b.modules && b.modules.length);

    var g = document.createElementNS(SVG_NS, 'g');
    g.setAttribute('class', 'mk' + (done ? '' : ' todo'));
    g.setAttribute('tabindex', '0');
    g.setAttribute('role', 'button');
    g.setAttribute('aria-label', 'Switchboard ' + b.id + ', ' + b.room);

    var pulse = document.createElementNS(SVG_NS, 'circle');
    pulse.setAttribute('class', 'mk-pulse');
    pulse.setAttribute('cx', b.x); pulse.setAttribute('cy', b.y); pulse.setAttribute('r', 5);

    var ring = document.createElementNS(SVG_NS, 'circle');
    ring.setAttribute('class', 'mk-ring');
    ring.setAttribute('cx', b.x); ring.setAttribute('cy', b.y); ring.setAttribute('r', 5);

    var core = document.createElementNS(SVG_NS, 'circle');
    core.setAttribute('class', 'mk-core');
    core.setAttribute('cx', b.x); core.setAttribute('cy', b.y); core.setAttribute('r', 1.9);

    var hit = document.createElementNS(SVG_NS, 'circle');
    hit.setAttribute('class', 'mk-hit');
    hit.setAttribute('cx', b.x); hit.setAttribute('cy', b.y); hit.setAttribute('r', 11);

    var lab = document.createElementNS(SVG_NS, 'text');
    lab.setAttribute('class', 'mk-label');
    lab.setAttribute('x', b.x); lab.setAttribute('y', b.y - 7.5);
    lab.setAttribute('text-anchor', 'middle');
    lab.textContent = b.id;

    markerScaled.push(
      { el: pulse, attr: 'r', v: 5 }, { el: ring, attr: 'r', v: 5 },
      { el: core, attr: 'r', v: 1.9 }, { el: hit, attr: 'r', v: 11 },
      { el: lab, attr: 'y', v: 0 }
    );
    // label offset scales too — store the anchor separately
    markerScaled[markerScaled.length - 1] = {
      el: lab, attr: 'y', v: 0, base: b.y, off: -7.5,
      set: function (k) { lab.setAttribute('y', (b.y - 7.5 * k).toFixed(2)); }
    };

    g.appendChild(pulse); g.appendChild(ring); g.appendChild(core);
    g.appendChild(lab); g.appendChild(hit);
    markers.appendChild(g);
    markerEls[b.id] = g;

    g.addEventListener('click', function (e) { e.stopPropagation(); open(b.id); });
    g.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(b.id); }
    });
  });

  /* ---------------- pan & zoom ---------------- */

  var MIN_W = 60, MAX_W = base[2] * 1.6;

  function clientToSvg(cx, cy) {
    var r = svg.getBoundingClientRect();
    // account for preserveAspectRatio letterboxing
    var scale = Math.min(r.width / view.w, r.height / view.h);
    var offX = (r.width - view.w * scale) / 2;
    var offY = (r.height - view.h * scale) / 2;
    return {
      x: view.x + (cx - r.left - offX) / scale,
      y: view.y + (cy - r.top - offY) / scale,
      scale: scale
    };
  }

  function zoomAt(cx, cy, factor) {
    var p = clientToSvg(cx, cy);
    var nw = Math.min(MAX_W, Math.max(MIN_W, view.w * factor));
    var k = nw / view.w;
    view.x = p.x - (p.x - view.x) * k;
    view.y = p.y - (p.y - view.y) * k;
    view.w = nw;
    view.h = view.h * k;
    applyView();
  }

  host.addEventListener('wheel', function (e) {
    e.preventDefault();
    zoomAt(e.clientX, e.clientY, Math.exp(e.deltaY * 0.0012));
  }, { passive: false });

  var drag = null;
  host.addEventListener('pointerdown', function (e) {
    if (e.target.closest('.mk')) return;
    drag = { id: e.pointerId, x: e.clientX, y: e.clientY, moved: false };
    host.setPointerCapture(e.pointerId);
    host.classList.add('dragging');
  });
  host.addEventListener('pointermove', function (e) {
    if (!drag || e.pointerId !== drag.id) return;
    var r = svg.getBoundingClientRect();
    var scale = Math.min(r.width / view.w, r.height / view.h);
    view.x -= (e.clientX - drag.x) / scale;
    view.y -= (e.clientY - drag.y) / scale;
    drag.x = e.clientX; drag.y = e.clientY; drag.moved = true;
    applyView();
  });
  function endDrag(e) {
    if (!drag || e.pointerId !== drag.id) return;
    drag = null; host.classList.remove('dragging');
  }
  host.addEventListener('pointerup', endDrag);
  host.addEventListener('pointercancel', endDrag);

  // pinch
  var pts = {}, pinch = null;
  host.addEventListener('pointerdown', function (e) { pts[e.pointerId] = e; });
  host.addEventListener('pointermove', function (e) {
    if (!(e.pointerId in pts)) return;
    pts[e.pointerId] = e;
    var ids = Object.keys(pts);
    if (ids.length !== 2) { pinch = null; return; }
    var a = pts[ids[0]], b = pts[ids[1]];
    var dist = Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
    var mx = (a.clientX + b.clientX) / 2, my = (a.clientY + b.clientY) / 2;
    if (pinch) { drag = null; zoomAt(mx, my, pinch / dist); }
    pinch = dist;
  });
  function clearPt(e) { delete pts[e.pointerId]; if (Object.keys(pts).length < 2) pinch = null; }
  host.addEventListener('pointerup', clearPt);
  host.addEventListener('pointercancel', clearPt);

  $('zoom-in').onclick = function () { var r = svg.getBoundingClientRect(); zoomAt(r.left + r.width / 2, r.top + r.height / 2, 1 / 1.35); };
  $('zoom-out').onclick = function () { var r = svg.getBoundingClientRect(); zoomAt(r.left + r.width / 2, r.top + r.height / 2, 1.35); };
  $('zoom-reset').onclick = function () { fit(); };

  function flyTo(b) {
    var targetW = Math.min(view.w, 340);
    view.h = targetW * (view.h / view.w);
    view.w = targetW;
    // if the side panel covers part of the stage, bias the centre left
    var bias = 0;
    if (!panel.hidden && !isNarrow()) {
      var r = svg.getBoundingClientRect();
      bias = (panel.getBoundingClientRect().width / r.width) * view.w * 0.5;
    }
    view.x = b.x - view.w / 2 + bias;
    view.y = b.y - view.h / 2;
    applyView();
  }

  /* ---------------- layers ---------------- */

  var layerBox = $('layers');
  D.layers.forEach(function (L) {
    var btn = document.createElement('button');
    btn.className = 'layer-chip';
    btn.type = 'button';
    btn.setAttribute('aria-pressed', String(L.on));
    if (L.locked) btn.setAttribute('data-locked', 'true');
    btn.style.color = 'var(--c-' + L.id + ')';
    btn.innerHTML = '<i class="swatch"></i><span>' + L.label + '</span>';
    if (!L.on) document.body.classList.add('off-' + L.id);
    btn.onclick = function () {
      if (L.locked) return;
      var on = btn.getAttribute('aria-pressed') !== 'true';
      btn.setAttribute('aria-pressed', String(on));
      document.body.classList.toggle('off-' + L.id, !on);
    };
    layerBox.appendChild(btn);
  });

  /* ---------------- index ---------------- */

  var listEl = $('index-list');

  function renderIndex(q) {
    q = (q || '').trim().toLowerCase();
    listEl.innerHTML = '';
    var shown = 0;
    D.rooms.forEach(function (room) {
      var items = D.boards.filter(function (b) {
        if (b.room !== room) return false;
        if (!q) return true;
        return (b.id + ' ' + b.room + ' ' + (b.title || '') + ' ' + (b.note || '')).toLowerCase().indexOf(q) > -1;
      });
      if (!items.length) return;
      shown += items.length;
      var wrap = document.createElement('div');
      wrap.className = 'room-group';
      var h = document.createElement('div');
      h.className = 'room-head';
      h.textContent = room;
      wrap.appendChild(h);
      items.forEach(function (b) {
        var done = !!(b.modules && b.modules.length);
        var btn = document.createElement('button');
        btn.className = 'board-btn' + (done ? ' done' : '');
        btn.type = 'button';
        btn.dataset.id = b.id;
        btn.innerHTML = '<span class="tag"></span><span class="name"></span>';
        btn.querySelector('.tag').textContent = b.id;
        btn.querySelector('.name').textContent = b.title || (done ? 'Switchboard' : 'Layout not added yet');
        btn.onclick = function () { open(b.id, true); };
        wrap.appendChild(btn);
      });
      listEl.appendChild(wrap);
    });
    if (!shown) {
      var p = document.createElement('p');
      p.className = 'empty-note';
      p.textContent = 'Nothing matches “' + q + '”.';
      listEl.appendChild(p);
    }
  }
  renderIndex();

  $('search').addEventListener('input', function (e) { renderIndex(e.target.value); });

  /* ---------------- panel ---------------- */

  var panel = $('panel'), panelBody = $('panel-body'), scrim = $('scrim');
  var current = null;
  var isNarrow = function () { return window.matchMedia('(max-width:900px)').matches; };

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function modulesHtml(b) {
    var T = D.moduleTypes;
    var total = b.modules.reduce(function (n, m) { return n + (m.w || 1); }, 0);
    var faces = b.faces || {};
    var html = '<div class="board-wrap">';
    if (faces.left || faces.right) {
      html += '<div class="board-faces">' +
        '<span>' + (faces.left ? '&larr; ' + esc(faces.left) : '') + '</span>' +
        '<span>' + (faces.right ? esc(faces.right) + ' &rarr;' : '') + '</span>' +
        '</div>';
    }
    html += '<div class="plate">';
    b.modules.forEach(function (m) {
      var t = T[m.type] || T.light;
      var w = (m.w || 1) === 1 ? 52 : (m.w || 1) * 50;
      html += '<div class="mod' + (m.optional ? ' optional' : '') + '" style="' +
        'width:' + w + 'px;--mod-fill:' + t.fill + ';--mod-stroke:' + t.stroke + ';--mod-text:' + t.text + '"' +
        ' title="' + esc(m.label) + (m.optional ? ' (optional)' : '') + '">' +
        (m.optional ? '<span class="opt">opt</span>' : '') +
        '<span>' + esc(m.label) + '</span>' +
        '</div>';
    });
    html += '</div>';
    html += '<div class="plate-meta"><span>' + b.modules.length + ' switches / points</span>' +
      '<span>approx. ' + total + 'M plate</span></div>';
    html += '</div>';

    // key of the types actually used
    var used = [];
    b.modules.forEach(function (m) { if (used.indexOf(m.type) < 0) used.push(m.type); });
    html += '<div class="pb-h">Key</div><div class="key">';
    used.forEach(function (k) {
      var t = T[k] || T.light;
      html += '<div class="key-row"><i class="key-sw" style="--k-f:' + t.fill + ';--k-s:' + t.stroke + '"></i>' + esc(t.label) + '</div>';
    });
    html += '</div>';
    return html;
  }

  function open(id, fly) {
    var b = byId[id];
    if (!b) return;
    current = id;

    Object.keys(markerEls).forEach(function (k) { markerEls[k].classList.remove('active'); });
    markerEls[id].classList.add('active');
    Array.prototype.forEach.call(listEl.querySelectorAll('.board-btn'), function (el) {
      el.setAttribute('aria-current', String(el.dataset.id === id));
    });

    var done = !!(b.modules && b.modules.length);
    var h = '';
    h += '<div class="pb-eyebrow"><span class="pb-id' + (done ? '' : ' todo') + '">' + esc(b.id) + '</span><span>' + esc(b.room) + '</span></div>';
    h += '<h2 class="pb-title" id="panel-title">' + esc(b.title || 'Switchboard ' + b.id) + '</h2>';
    h += '<p class="pb-sub">' + esc(b.note || (done ? '' : 'No layout recorded for this board yet.')) + '</p>';

    if (done) {
      if (b.source === 'figma' && b.confirmed === false) {
        h += '<div class="flag"><svg viewBox="0 0 24 24"><path d="M12 8v5M12 16.5v.01"/><circle cx="12" cy="12" r="9"/></svg>' +
             '<span>Layout taken from your Figma board. Which physical board it maps to is a <b>best guess</b> — confirm or change it in <code>assets/data/boards.js</code>.</span></div>';
      }
      h += modulesHtml(b);
    } else {
      h += '<div class="flag todo"><svg viewBox="0 0 24 24"><path d="M12 8v5M12 16.5v.01"/><circle cx="12" cy="12" r="9"/></svg>' +
           '<span>Add this one by giving <code>' + esc(b.id) + '</code> a <code>modules</code> array in <code>assets/data/boards.js</code>.</span></div>';
    }

    h += '<div class="pb-h">Location</div><dl class="kv">' +
         '<dt>Room</dt><dd>' + esc(b.room) + '</dd>' +
         '<dt>Board</dt><dd>' + esc(b.id) + '</dd>' +
         '<dt>On drawing</dt><dd>x ' + b.x + ', y ' + b.y + '</dd>' +
         '</dl>';

    h += '<div class="pb-actions"><button class="btn" id="btn-locate">Zoom to this board</button></div>';

    panelBody.innerHTML = h;
    panel.hidden = false;
    scrim.hidden = !isNarrow();

    var loc = $('btn-locate');
    if (loc) loc.onclick = function () { flyTo(b); };
    if (fly) flyTo(b);

    $('hint').classList.add('gone');
  }

  function close() {
    panel.hidden = true;
    scrim.hidden = true;
    current = null;
    Object.keys(markerEls).forEach(function (k) { markerEls[k].classList.remove('active'); });
    Array.prototype.forEach.call(listEl.querySelectorAll('.board-btn'), function (el) {
      el.setAttribute('aria-current', 'false');
    });
  }

  $('panel-close').onclick = close;
  scrim.onclick = close;
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') close();
    if (e.key === '/' && document.activeElement !== $('search')) { e.preventDefault(); $('search').focus(); }
  });

  /* ---------------- chrome ---------------- */

  var btnIndex = $('btn-index');
  if (isNarrow()) document.body.classList.add('no-index');
  btnIndex.onclick = function () {
    var hidden = document.body.classList.toggle('no-index');
    btnIndex.setAttribute('aria-expanded', String(!hidden));
  };
  btnIndex.setAttribute('aria-expanded', String(!document.body.classList.contains('no-index')));

  var btnTheme = $('btn-theme');
  try {
    var saved = localStorage.getItem('gr-theme');
    if (saved) document.documentElement.setAttribute('data-theme', saved);
  } catch (err) { /* storage unavailable */ }
  btnTheme.onclick = function () {
    var cur = document.documentElement.getAttribute('data-theme');
    if (!cur) cur = window.matchMedia('(prefers-color-scheme:dark)').matches ? 'dark' : 'light';
    var next = cur === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    try { localStorage.setItem('gr-theme', next); } catch (err) { /* ignore */ }
  };

  setTimeout(function () { $('hint').classList.add('gone'); }, 7000);

  // deep link: index.html#S13
  var hash = (location.hash || '').replace('#', '');
  if (hash && byId[hash]) open(hash, true);
  window.addEventListener('hashchange', function () {
    var h2 = (location.hash || '').replace('#', '');
    if (h2 && byId[h2]) open(h2, true);
  });
})();
