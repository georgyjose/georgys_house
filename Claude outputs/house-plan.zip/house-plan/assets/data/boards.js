// Georgy Residence — switchboard data.
// Boards with a `modules` array are documented; the rest are placeholders
// waiting for their layout. Add one by filling in `modules`.
window.HOUSE_DATA = {
 "meta": {
  "title": "Georgy Residence",
  "subtitle": "Electrical drawing \u2014 Rev 5",
  "drawing": {
   "by": "Sourorja Electricals",
   "rev": "5",
   "date": "2026-01-16",
   "project": "Georgy Jose",
   "sheet": "1"
  },
  "viewBox": "16 16 928 804"
 },
 "layers": [
  {
   "id": "arch",
   "label": "Architecture",
   "on": true,
   "locked": true,
   "colour": "#1f2937"
  },
  {
   "id": "fixtures",
   "label": "Lights, fans & sockets",
   "on": true,
   "colour": "#e5157f"
  },
  {
   "id": "switches",
   "label": "Switches & boards",
   "on": true,
   "colour": "#7c3aed"
  },
  {
   "id": "wiring",
   "label": "Control wiring",
   "on": false,
   "colour": "#ef4444"
  },
  {
   "id": "notes",
   "label": "Extra notes",
   "on": false,
   "colour": "#16a34a"
  }
 ],
 "moduleTypes": {
  "light": {
   "label": "Light switch",
   "fill": "#ffffff",
   "stroke": "#94a3b8",
   "text": "#0f172a"
  },
  "fan": {
   "label": "Fan / regulator",
   "fill": "#bfe6fb",
   "stroke": "#3b9fd4",
   "text": "#0c3b52"
  },
  "socket": {
   "label": "Plug point",
   "fill": "#ffe6a8",
   "stroke": "#d9a326",
   "text": "#4a3305"
  },
  "socket-switch": {
   "label": "Switch for plug point",
   "fill": "#ffe6a8",
   "stroke": "#d9a326",
   "text": "#4a3305"
  },
  "heavy": {
   "label": "High load (AC / geyser)",
   "fill": "#ffc9c4",
   "stroke": "#e06c5f",
   "text": "#5c1a13"
  }
 },
 "rooms": [
  "Bathroom (Master)",
  "Bathroom 2",
  "Bathroom 4 / Wash",
  "Bedroom 2",
  "Bedroom 3",
  "Bedroom 4",
  "Car Porch",
  "Day Bed / Jali",
  "Dining / Family Living",
  "Dress (Master)",
  "Dress / Bath (Bedroom 3)",
  "Formal Living",
  "Kitchen",
  "Master Bedroom",
  "Patio",
  "Sitout",
  "Store / Utility"
 ],
 "boards": [
  {
   "id": "S13",
   "room": "Bathroom (Master)",
   "x": 244.5,
   "y": 683.6,
   "title": "Outside of Bathroom",
   "note": "",
   "faces": {
    "right": "Bathroom door"
   },
   "modules": [
    {
     "label": "Geyser switch",
     "type": "heavy",
     "w": 1
    },
    {
     "label": "Exhaust fan",
     "type": "fan",
     "w": 1
    },
    {
     "label": "Ceiling lights",
     "type": "light",
     "w": 1
    }
   ],
   "source": "figma",
   "confirmed": false
  },
  {
   "id": "S9",
   "room": "Bathroom 2",
   "x": 322.0,
   "y": 578.2
  },
  {
   "id": "S9A",
   "room": "Bathroom 2",
   "x": 328.0,
   "y": 593.8
  },
  {
   "id": "S10",
   "room": "Bathroom 2",
   "x": 312.4,
   "y": 580.7
  },
  {
   "id": "S27",
   "room": "Bathroom 4 / Wash",
   "x": 763.0,
   "y": 328.2
  },
  {
   "id": "S27A",
   "room": "Bathroom 4 / Wash",
   "x": 729.7,
   "y": 327.9
  },
  {
   "id": "S28",
   "room": "Bathroom 4 / Wash",
   "x": 775.9,
   "y": 324.6
  },
  {
   "id": "S29",
   "room": "Bathroom 4 / Wash",
   "x": 713.2,
   "y": 356.4
  },
  {
   "id": "S5",
   "room": "Bedroom 2",
   "x": 387.4,
   "y": 465.5
  },
  {
   "id": "S6",
   "room": "Bedroom 2",
   "x": 387.4,
   "y": 490.8
  },
  {
   "id": "S7",
   "room": "Bedroom 2",
   "x": 321.7,
   "y": 534.7
  },
  {
   "id": "S8",
   "room": "Bedroom 2",
   "x": 255.8,
   "y": 534.7
  },
  {
   "id": "S30",
   "room": "Bedroom 3",
   "x": 695.4,
   "y": 231.4
  },
  {
   "id": "S31",
   "room": "Bedroom 3",
   "x": 695.9,
   "y": 219.1
  },
  {
   "id": "S32",
   "room": "Bedroom 3",
   "x": 710.4,
   "y": 219.0
  },
  {
   "id": "S33",
   "room": "Bedroom 3",
   "x": 776.5,
   "y": 219.0
  },
  {
   "id": "S24",
   "room": "Bedroom 4",
   "x": 763.2,
   "y": 486.4
  },
  {
   "id": "S25",
   "room": "Bedroom 4",
   "x": 829.1,
   "y": 486.4
  },
  {
   "id": "S26",
   "room": "Bedroom 4",
   "x": 720.8,
   "y": 410.6
  },
  {
   "id": "S2A",
   "room": "Car Porch",
   "x": 235.6,
   "y": 153.7
  },
  {
   "id": "S3A",
   "room": "Day Bed / Jali",
   "x": 447.7,
   "y": 226.9
  },
  {
   "id": "S3B",
   "room": "Day Bed / Jali",
   "x": 601.9,
   "y": 219.0
  },
  {
   "id": "S3G",
   "room": "Day Bed / Jali",
   "x": 400.0,
   "y": 220.9
  },
  {
   "id": "S3C",
   "room": "Dining / Family Living",
   "x": 399.9,
   "y": 333.0
  },
  {
   "id": "S3D",
   "room": "Dining / Family Living",
   "x": 399.9,
   "y": 366.6
  },
  {
   "id": "S3E",
   "room": "Dining / Family Living",
   "x": 399.9,
   "y": 349.5
  },
  {
   "id": "S4",
   "room": "Dining / Family Living",
   "x": 436.4,
   "y": 427.0
  },
  {
   "id": "S17",
   "room": "Dining / Family Living",
   "x": 658.8,
   "y": 427.0
  },
  {
   "id": "S14",
   "room": "Dress (Master)",
   "x": 252.9,
   "y": 692.4,
   "title": "Inside of Bathroom",
   "note": "",
   "faces": {
    "left": "Bathroom door"
   },
   "modules": [
    {
     "label": "Mirror light",
     "type": "light",
     "w": 1
    },
    {
     "label": "Switch for Plug Point",
     "type": "socket-switch",
     "w": 1
    },
    {
     "label": "Plug Point",
     "type": "socket",
     "w": 2
    }
   ],
   "source": "figma",
   "confirmed": false
  },
  {
   "id": "S14A",
   "room": "Dress (Master)",
   "x": 253.2,
   "y": 734.7,
   "title": "Dressing Table",
   "note": "",
   "faces": {
    "right": "Dressing table chair"
   },
   "modules": [
    {
     "label": "Plug Point",
     "type": "socket",
     "w": 2
    },
    {
     "label": "Switch for Plug Point",
     "type": "socket-switch",
     "w": 1
    },
    {
     "label": "Dressing table light",
     "type": "light",
     "w": 1
    },
    {
     "label": "Roof light",
     "type": "light",
     "w": 1
    }
   ],
   "source": "figma",
   "confirmed": false
  },
  {
   "id": "S34",
   "room": "Dress / Bath (Bedroom 3)",
   "x": 836.5,
   "y": 132.8
  },
  {
   "id": "S34A",
   "room": "Dress / Bath (Bedroom 3)",
   "x": 836.6,
   "y": 98.1
  },
  {
   "id": "S35",
   "room": "Dress / Bath (Bedroom 3)",
   "x": 845.2,
   "y": 141.5
  },
  {
   "id": "S2",
   "room": "Formal Living",
   "x": 331.6,
   "y": 159.7
  },
  {
   "id": "S3",
   "room": "Formal Living",
   "x": 389.9,
   "y": 273.1
  },
  {
   "id": "S3F",
   "room": "Formal Living",
   "x": 255.7,
   "y": 273.4
  },
  {
   "id": "S19",
   "room": "Kitchen",
   "x": 658.2,
   "y": 641.8
  },
  {
   "id": "S19A",
   "room": "Kitchen",
   "x": 658.3,
   "y": 560.2
  },
  {
   "id": "S20A",
   "room": "Kitchen",
   "x": 766.0,
   "y": 651.1
  },
  {
   "id": "S20B",
   "room": "Kitchen",
   "x": 709.3,
   "y": 651.3
  },
  {
   "id": "S22",
   "room": "Kitchen",
   "x": 790.4,
   "y": 502.8
  },
  {
   "id": "S22A",
   "room": "Kitchen",
   "x": 790.5,
   "y": 550.8
  },
  {
   "id": "S22B",
   "room": "Kitchen",
   "x": 790.5,
   "y": 565.1
  },
  {
   "id": "S23",
   "room": "Kitchen",
   "x": 716.7,
   "y": 499.9
  },
  {
   "id": "S11",
   "room": "Master Bedroom",
   "x": 397.8,
   "y": 606.2,
   "title": "Main Switch Board",
   "note": "The one closer to the door",
   "faces": {
    "left": "Door"
   },
   "modules": [
    {
     "label": "Tube",
     "type": "light",
     "w": 1
    },
    {
     "label": "Fan (2 way)",
     "type": "fan",
     "w": 1
    },
    {
     "label": "Roof lights",
     "type": "light",
     "w": 1
    },
    {
     "label": "AC",
     "type": "heavy",
     "w": 2
    }
   ],
   "source": "figma",
   "confirmed": false
  },
  {
   "id": "S12",
   "room": "Master Bedroom",
   "x": 347.8,
   "y": 606.2,
   "title": "Above Table",
   "note": "",
   "faces": {
    "left": "Table"
   },
   "modules": [
    {
     "label": "Table lamp",
     "type": "light",
     "w": 1
    },
    {
     "label": "Switch for Plug Point",
     "type": "socket-switch",
     "w": 1
    },
    {
     "label": "Plug Point",
     "type": "socket",
     "w": 2
    },
    {
     "label": "Wardrobe light",
     "type": "light",
     "w": 1
    }
   ],
   "source": "figma",
   "confirmed": false
  },
  {
   "id": "S15",
   "room": "Master Bedroom",
   "x": 329.0,
   "y": 735.0,
   "title": "Bedside switch",
   "note": "Away from the room door",
   "faces": {
    "left": "Bed"
   },
   "modules": [
    {
     "label": "Bedside lamp on top",
     "type": "light",
     "w": 1
    },
    {
     "label": "Fan (2 way)",
     "type": "fan",
     "w": 1
    },
    {
     "label": "Fan Regulator",
     "type": "fan",
     "w": 2
    },
    {
     "label": "Switch for Plug Point",
     "type": "socket-switch",
     "w": 1
    },
    {
     "label": "Plug Point",
     "type": "socket",
     "w": 2
    },
    {
     "label": "Sunshade Light",
     "type": "light",
     "w": 1,
     "optional": true
    }
   ],
   "source": "figma",
   "confirmed": false
  },
  {
   "id": "S16",
   "room": "Master Bedroom",
   "x": 407.9,
   "y": 735.0,
   "title": "Bedside switch",
   "note": "Closer to the room door",
   "faces": {
    "left": "Bed",
    "right": "Door"
   },
   "modules": [
    {
     "label": "Bedside lamp on top",
     "type": "light",
     "w": 1
    },
    {
     "label": "Foot lamp",
     "type": "light",
     "w": 1
    },
    {
     "label": "Switch for Plug Point",
     "type": "socket-switch",
     "w": 1
    },
    {
     "label": "Plug Point",
     "type": "socket",
     "w": 2
    },
    {
     "label": "Sunshade Light",
     "type": "light",
     "w": 1,
     "optional": true
    },
    {
     "label": "Master Switch",
     "type": "light",
     "w": 1,
     "optional": true
    }
   ],
   "source": "figma",
   "confirmed": false
  },
  {
   "id": "S18",
   "room": "Patio",
   "x": 670.5,
   "y": 487.0
  },
  {
   "id": "S1",
   "room": "Sitout",
   "x": 393.4,
   "y": 85.8
  },
  {
   "id": "S20",
   "room": "Store / Utility",
   "x": 814.4,
   "y": 651.1
  },
  {
   "id": "S21",
   "room": "Store / Utility",
   "x": 853.0,
   "y": 548.3
  },
  {
   "id": "S21A",
   "room": "Store / Utility",
   "x": 853.3,
   "y": 598.5
  },
  {
   "id": "S21B",
   "room": "Store / Utility",
   "x": 805.9,
   "y": 499.5
  }
 ]
};
